import {
  applySupersessionStates,
  bindCanonicalEntities,
  buildClaimLedger,
  moneySweepIdentityContract,
  normalizeEntityNameForSearch,
  resolveGovernmentRoleAt,
  toNormalizedEntity,
  type GovernmentRole,
  type RawEntityRecord,
} from "./moneySweepIdentity";

const source = (sourceId: string) => ({
  sourceId,
  sourceUrl: `https://example.test/${sourceId}`,
  sha256: sourceId.padEnd(64, "a").slice(0, 64),
  retrievedAt: "2026-09-01T00:00:00Z",
});

const raw = (id: string, name: string, identifiers: RawEntityRecord["identifiers"]): RawEntityRecord => ({
  sourceRecordId: id,
  legalName: name,
  identifiers,
  source: source(`src-${id}`),
});

describe("MoneySweep identity planes", () => {
  it("normalizes names only for search and keeps RAW separate", () => {
    const record = raw("r1", "Acme, LLC", {});
    const normalized = toNormalizedEntity(record);
    expect(normalized.plane).toBe("NORMALIZED");
    expect(normalized.normalizedName).toBe("ACME");
    expect(record).not.toHaveProperty("plane");
  });

  it("does not create canonical identity from equal normalized names", () => {
    const bindings = bindCanonicalEntities([raw("a", "Acme LLC", {}), raw("b", "ACME, INC.", {})]);
    expect(bindings).toHaveLength(2);
    expect(bindings.every((row) => row.state === "CANDIDATE_NOT_IDENTITY")).toBeTrue();
    expect(bindings.every((row) => row.canonicalId === null)).toBeTrue();
  });

  it("binds records by exact UEI", () => {
    const bindings = bindCanonicalEntities([raw("a", "A", { uei: "ABC123" }), raw("b", "B", { uei: "abc123" })]);
    expect(bindings).toHaveLength(1);
    expect(bindings[0].state).toBe("BOUND");
    expect(bindings[0].matchedBy).toBe("UEI");
    expect(bindings[0].canonicalId).toBe("UEI:ABC123");
    expect(bindings[0].sourceRecordIds).toEqual(["a", "b"]);
  });

  it("keeps CAGE identity independent from display names", () => {
    const bindings = bindCanonicalEntities([raw("a", "Alpha", { cage: "1A2B3" }), raw("b", "Completely Different", { cage: "1a2b3" })]);
    expect(bindings[0].state).toBe("BOUND");
    expect(bindings[0].matchedBy).toBe("CAGE");
  });

  it("preserves authoritative identifier priority UEI before CAGE", () => {
    const binding = bindCanonicalEntities([raw("a", "Alpha", { uei: "U1", cage: "C1" })])[0];
    expect(binding.canonicalId).toBe("UEI:U1");
    expect(binding.matchedBy).toBe("UEI");
  });

  it("publishes an explicit three-plane identity contract", () => {
    expect(moneySweepIdentityContract.planes).toEqual(["RAW", "NORMALIZED", "CANONICAL"]);
    expect(moneySweepIdentityContract.normalizedNameAuthority).toBe("DISCOVERY_ONLY");
    expect(moneySweepIdentityContract.zeroRowEventFabrication).toBe("DENY");
  });
});

describe("MoneySweep temporal government identity", () => {
  const roles: GovernmentRole[] = [
    { roleId: "role-1", personEntityId: "person-a", officeEntityId: "office-x", effectiveFrom: "2024-01-01T00:00:00Z", effectiveTo: "2025-01-01T00:00:00Z", sourceRef: "manifest-a" },
    { roleId: "role-2", personEntityId: "person-b", officeEntityId: "office-x", effectiveFrom: "2025-01-01T00:00:00Z", effectiveTo: null, sourceRef: "manifest-b" },
  ];

  it("resolves the officeholder valid at an exact instant", () => {
    const result = resolveGovernmentRoleAt(roles, "office-x", "2024-06-01T00:00:00Z");
    expect(result.state).toBe("BOUND");
    expect(result.role?.personEntityId).toBe("person-a");
  });

  it("uses half-open effective periods at succession", () => {
    const result = resolveGovernmentRoleAt(roles, "office-x", "2025-01-01T00:00:00Z");
    expect(result.state).toBe("BOUND");
    expect(result.role?.personEntityId).toBe("person-b");
  });

  it("returns unresolved instead of fabricating a zero-row event", () => {
    const result = resolveGovernmentRoleAt(roles, "office-y", "2025-06-01T00:00:00Z");
    expect(result.state).toBe("UNRESOLVED");
    expect(result.fabricatedZeroRowEvent).toBeFalse();
  });

  it("fails closed when government role periods overlap", () => {
    const overlapping = [...roles, { ...roles[1], roleId: "role-3", personEntityId: "person-c", effectiveFrom: "2025-03-01T00:00:00Z" }];
    const result = resolveGovernmentRoleAt(overlapping, "office-x", "2025-06-01T00:00:00Z");
    expect(result.state).toBe("CONTRADICTED");
    expect(result.role).toBeNull();
  });
});

describe("MoneySweep claim lifecycle", () => {
  it("keeps an unsourced claim unresolved", () => {
    const [claim] = buildClaimLedger([{ claimId: "c1", subjectId: "e1", predicate: "status", objectValue: "active", sourceRef: null, observedAt: "2025-01-01T00:00:00Z" }]);
    expect(claim.state).toBe("UNRESOLVED");
    expect(claim.reasons).toContain("MISSING_SOURCE_REFERENCE");
  });

  it("marks two source-backed conflicting claims as contradicted without choosing a winner", () => {
    const claims = buildClaimLedger([
      { claimId: "c1", subjectId: "e1", predicate: "owner", objectValue: "p1", sourceRef: "s1", observedAt: "2025-01-01T00:00:00Z" },
      { claimId: "c2", subjectId: "e1", predicate: "owner", objectValue: "p2", sourceRef: "s2", observedAt: "2025-01-02T00:00:00Z", contradictsClaimId: "c1" },
    ]);
    expect(claims.find((c) => c.claimId === "c2")?.state).toBe("CONTRADICTED");
    expect(claims.find((c) => c.claimId === "c1")?.state).toBe("ASSERTED");
  });

  it("does not create a contradiction state from an unsourced conflicting assertion", () => {
    const claims = buildClaimLedger([
      { claimId: "c1", subjectId: "e1", predicate: "owner", objectValue: "p1", sourceRef: "s1", observedAt: "2025-01-01T00:00:00Z" },
      { claimId: "c2", subjectId: "e1", predicate: "owner", objectValue: "p2", sourceRef: null, observedAt: "2025-01-02T00:00:00Z", contradictsClaimId: "c1" },
    ]);
    expect(claims.find((c) => c.claimId === "c2")?.state).toBe("UNRESOLVED");
  });

  it("supersedes an earlier claim only from a source-backed successor", () => {
    const base = buildClaimLedger([
      { claimId: "c1", subjectId: "e1", predicate: "name", objectValue: "Old", sourceRef: "s1", observedAt: "2025-01-01T00:00:00Z" },
      { claimId: "c2", subjectId: "e1", predicate: "name", objectValue: "New", sourceRef: "s2", observedAt: "2026-01-01T00:00:00Z", supersedesClaimId: "c1" },
    ]);
    const claims = applySupersessionStates(base);
    expect(claims.find((c) => c.claimId === "c1")?.state).toBe("SUPERSEDED");
    expect(claims.find((c) => c.claimId === "c2")?.state).toBe("ASSERTED");
  });

  it("does not supersede a prior claim when the successor lacks evidence", () => {
    const base = buildClaimLedger([
      { claimId: "c1", subjectId: "e1", predicate: "name", objectValue: "Old", sourceRef: "s1", observedAt: "2025-01-01T00:00:00Z" },
      { claimId: "c2", subjectId: "e1", predicate: "name", objectValue: "New", sourceRef: null, observedAt: "2026-01-01T00:00:00Z", supersedesClaimId: "c1" },
    ]);
    const claims = applySupersessionStates(base);
    expect(claims.find((c) => c.claimId === "c1")?.state).toBe("ASSERTED");
    expect(claims.find((c) => c.claimId === "c2")?.state).toBe("UNRESOLVED");
  });
});
