export type IdentityState = "BOUND" | "CANDIDATE_NOT_IDENTITY" | "UNRESOLVED" | "CONTRADICTED";
export type ClaimState = "ASSERTED" | "CONTRADICTED" | "SUPERSEDED" | "UNRESOLVED";
export type EntityPlane = "RAW" | "NORMALIZED" | "CANONICAL";

export type SourceManifestation = {
  sourceId: string;
  sourceUrl: string | null;
  sha256: string | null;
  retrievedAt: string | null;
};

export type EntityIdentifiers = {
  uei?: string | null;
  cage?: string | null;
  duns?: string | null;
  registryId?: string | null;
};

export type RawEntityRecord = {
  sourceRecordId: string;
  legalName: string;
  identifiers: EntityIdentifiers;
  source: SourceManifestation;
  effectiveFrom?: string | null;
  effectiveTo?: string | null;
};

export type NormalizedEntityRecord = RawEntityRecord & {
  plane: "NORMALIZED";
  normalizedName: string;
};

export type CanonicalEntityBinding = {
  plane: "CANONICAL";
  state: IdentityState;
  canonicalId: string | null;
  matchedBy: "UEI" | "CAGE" | "DUNS" | "REGISTRY_ID" | null;
  sourceRecordIds: string[];
  unresolvedReasons: string[];
};

export type GovernmentRole = {
  roleId: string;
  personEntityId: string;
  officeEntityId: string;
  effectiveFrom: string;
  effectiveTo: string | null;
  sourceRef: string;
};

export type ClaimInput = {
  claimId: string;
  subjectId: string;
  predicate: string;
  objectValue: string;
  sourceRef: string | null;
  observedAt: string;
  supersedesClaimId?: string | null;
  contradictsClaimId?: string | null;
};

export type ClaimRecord = ClaimInput & {
  state: ClaimState;
  reasons: string[];
};

const cleanIdentifier = (value: string | null | undefined) => {
  const cleaned = (value ?? "").trim().toUpperCase();
  return cleaned || null;
};

export const normalizeEntityNameForSearch = (name: string) =>
  name
    .normalize("NFKD")
    .replace(/[\u0300-\u036f]/g, "")
    .toUpperCase()
    .replace(/\b(INC|INCORPORATED|LLC|L L C|CORP|CORPORATION|LTD|LIMITED)\b/g, " ")
    .replace(/[^A-Z0-9]+/g, " ")
    .trim()
    .replace(/\s+/g, " ");

export function toNormalizedEntity(record: RawEntityRecord): NormalizedEntityRecord {
  return {
    ...record,
    plane: "NORMALIZED",
    normalizedName: normalizeEntityNameForSearch(record.legalName),
  };
}

const orderedIdentifiers: Array<[keyof EntityIdentifiers, CanonicalEntityBinding["matchedBy"]]> = [
  ["uei", "UEI"],
  ["cage", "CAGE"],
  ["duns", "DUNS"],
  ["registryId", "REGISTRY_ID"],
];

export function bindCanonicalEntities(records: RawEntityRecord[]): CanonicalEntityBinding[] {
  const byIdentifier = new Map<string, RawEntityRecord[]>();
  for (const record of records) {
    for (const [key, kind] of orderedIdentifiers) {
      const value = cleanIdentifier(record.identifiers[key]);
      if (!value) continue;
      const token = `${kind}:${value}`;
      const rows = byIdentifier.get(token) ?? [];
      rows.push(record);
      byIdentifier.set(token, rows);
    }
  }

  const visited = new Set<string>();
  const bindings: CanonicalEntityBinding[] = [];

  for (const record of [...records].sort((a, b) => a.sourceRecordId.localeCompare(b.sourceRecordId))) {
    if (visited.has(record.sourceRecordId)) continue;

    let matched: RawEntityRecord[] = [];
    let matchedBy: CanonicalEntityBinding["matchedBy"] = null;
    let canonicalId: string | null = null;

    for (const [key, kind] of orderedIdentifiers) {
      const value = cleanIdentifier(record.identifiers[key]);
      if (!value) continue;
      const candidate = byIdentifier.get(`${kind}:${value}`) ?? [];
      if (candidate.length) {
        matched = candidate;
        matchedBy = kind;
        canonicalId = `${kind}:${value}`;
        break;
      }
    }

    if (!matched.length) {
      visited.add(record.sourceRecordId);
      bindings.push({
        plane: "CANONICAL",
        state: "CANDIDATE_NOT_IDENTITY",
        canonicalId: null,
        matchedBy: null,
        sourceRecordIds: [record.sourceRecordId],
        unresolvedReasons: ["NO_AUTHORITATIVE_IDENTIFIER", "NORMALIZED_NAME_IS_DISCOVERY_ONLY"],
      });
      continue;
    }

    const candidateIds = new Set<string>();
    for (const row of matched) {
      for (const [key, kind] of orderedIdentifiers) {
        const value = cleanIdentifier(row.identifiers[key]);
        if (value) candidateIds.add(`${kind}:${value}`);
      }
    }

    const contradictory = candidateIds.size > matched.length + 2;
    for (const row of matched) visited.add(row.sourceRecordId);
    bindings.push({
      plane: "CANONICAL",
      state: contradictory ? "CONTRADICTED" : "BOUND",
      canonicalId: contradictory ? null : canonicalId,
      matchedBy: contradictory ? null : matchedBy,
      sourceRecordIds: matched.map((row) => row.sourceRecordId).sort(),
      unresolvedReasons: contradictory ? ["IDENTIFIER_CONTRADICTION_REQUIRES_ADJUDICATION"] : [],
    });
  }

  return bindings;
}

const parseInstant = (value: string) => {
  const ms = Date.parse(value);
  if (!Number.isFinite(ms)) throw new Error(`Invalid instant: ${value}`);
  return ms;
};

export function resolveGovernmentRoleAt(roles: GovernmentRole[], officeEntityId: string, at: string) {
  const instant = parseInstant(at);
  const candidates = roles
    .filter((role) => role.officeEntityId === officeEntityId)
    .filter((role) => parseInstant(role.effectiveFrom) <= instant)
    .filter((role) => role.effectiveTo === null || instant < parseInstant(role.effectiveTo))
    .sort((a, b) => a.roleId.localeCompare(b.roleId));

  if (candidates.length === 0) {
    return {
      state: "UNRESOLVED" as const,
      role: null,
      reason: "NO_EVIDENCED_ROLE_FOR_INSTANT",
      fabricatedZeroRowEvent: false,
    };
  }
  if (candidates.length > 1) {
    return {
      state: "CONTRADICTED" as const,
      role: null,
      reason: "OVERLAPPING_ROLE_PERIODS_REQUIRE_ADJUDICATION",
      fabricatedZeroRowEvent: false,
    };
  }
  return {
    state: "BOUND" as const,
    role: candidates[0],
    reason: null,
    fabricatedZeroRowEvent: false,
  };
}

export function buildClaimLedger(inputs: ClaimInput[]): ClaimRecord[] {
  const byId = new Map(inputs.map((claim) => [claim.claimId, claim] as const));
  return [...inputs]
    .sort((a, b) => a.claimId.localeCompare(b.claimId))
    .map((claim): ClaimRecord => {
      const reasons: string[] = [];
      let state: ClaimState = claim.sourceRef ? "ASSERTED" : "UNRESOLVED";
      if (!claim.sourceRef) reasons.push("MISSING_SOURCE_REFERENCE");

      if (claim.supersedesClaimId) {
        if (byId.has(claim.supersedesClaimId) && claim.sourceRef) {
          state = "ASSERTED";
          reasons.push(`SUPERSEDES:${claim.supersedesClaimId}`);
        } else {
          state = "UNRESOLVED";
          reasons.push("SUPERSEDED_TARGET_OR_SOURCE_MISSING");
        }
      }

      if (claim.contradictsClaimId) {
        const target = byId.get(claim.contradictsClaimId);
        if (target?.sourceRef && claim.sourceRef) {
          state = "CONTRADICTED";
          reasons.push(`CONTRADICTS:${claim.contradictsClaimId}`);
        } else {
          state = "UNRESOLVED";
          reasons.push("CONTRADICTION_NOT_SOURCE_BACKED");
        }
      }

      return { ...claim, state, reasons };
    });
}

export function applySupersessionStates(records: ClaimRecord[]): ClaimRecord[] {
  const superseded = new Set(
    records
      .filter((record) => record.state !== "UNRESOLVED" && record.supersedesClaimId)
      .map((record) => record.supersedesClaimId as string),
  );
  return records.map((record) =>
    superseded.has(record.claimId) && record.state !== "UNRESOLVED"
      ? { ...record, state: "SUPERSEDED" as const, reasons: [...record.reasons, "SUPERSEDED_BY_SOURCE_BACKED_CLAIM"] }
      : record,
  );
}

export const moneySweepIdentityContract = {
  schema: "moneysweep-identity-lifecycle/v1" as const,
  planes: ["RAW", "NORMALIZED", "CANONICAL"] as const,
  normalizedNameAuthority: "DISCOVERY_ONLY" as const,
  authoritativeIdentifiers: ["UEI", "CAGE", "DUNS", "REGISTRY_ID"] as const,
  zeroRowEventFabrication: "DENY" as const,
  claimStates: ["ASSERTED", "CONTRADICTED", "SUPERSEDED", "UNRESOLVED"] as const,
};
