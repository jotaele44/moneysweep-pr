import { buildSourceCoverageReceipt, compareSourceManifestations, moneySweepSourceCoverageContract, rankStableRows, validateSourceManifestations, type SourceManifestation } from "./moneySweepSourceCoverage";

const sha = (c: string) => c.repeat(64).slice(0, 64);
const row = (sourceId: string, state: SourceManifestation["state"], overrides: Partial<SourceManifestation> = {}): SourceManifestation => ({
  sourceId,
  state,
  required: true,
  sha256: state === "AVAILABLE" ? sha("a") : null,
  rows: state === "AVAILABLE" ? 10 : null,
  bytes: state === "AVAILABLE" ? 100 : null,
  retrievedAt: state === "AVAILABLE" ? "2026-10-04T00:00:00Z" : null,
  evidenceRef: state === "NO_DATA" ? `receipt:${sourceId}` : null,
  ...overrides,
});

describe("MoneySweep source coverage", () => {
  it("requires immutable hashes, row counts, bytes and UTC retrieval for AVAILABLE", () => {
    const result = validateSourceManifestations([row("s1", "AVAILABLE", { sha256: null })]);
    expect(result.valid).toBeFalse();
    expect(result.reasons).toContain("AVAILABLE_WITHOUT_SHA256:s1");
  });

  it("requires evidence for a terminal NO_DATA result", () => {
    const result = validateSourceManifestations([row("s1", "NO_DATA", { evidenceRef: null })]);
    expect(result.valid).toBeFalse();
    expect(result.reasons).toContain("NO_DATA_WITHOUT_EVIDENCE:s1");
  });

  it("rejects duplicate source IDs", () => {
    const result = validateSourceManifestations([row("s1", "AVAILABLE"), row("s1", "NO_DATA")]);
    expect(result.valid).toBeFalse();
    expect(result.reasons).toContain("DUPLICATE_SOURCE_ID:s1");
  });

  it("closes only when every required source is terminal and valid", () => {
    const receipt = buildSourceCoverageReceipt([row("a", "AVAILABLE"), row("b", "NO_DATA")]);
    expect(receipt.complete).toBeTrue();
    expect(receipt.materialRequiredResidue).toBe(0);
    expect(receipt.publicDataCoverage).toBe(1);
  });

  it("keeps FAILED, UNRESOLVED and PENDING as material residue", () => {
    const receipt = buildSourceCoverageReceipt([row("a", "FAILED"), row("b", "UNRESOLVED"), row("c", "PENDING")]);
    expect(receipt.complete).toBeFalse();
    expect(receipt.materialRequiredResidue).toBe(3);
  });

  it("reports public and resolvable coverage separately when a source is structurally blocked", () => {
    const receipt = buildSourceCoverageReceipt([row("a", "AVAILABLE"), row("b", "BLOCKED")]);
    expect(receipt.publicDataCoverage).toBe(0.5);
    expect(receipt.resolvableCoverage).toBe(1);
    expect(receipt.complete).toBeFalse();
  });
});

describe("MoneySweep source drift", () => {
  it("requires immutable hashes rather than equal row counts", () => {
    const a = row("s", "AVAILABLE", { sha256: null, rows: 10 });
    const b = row("s", "AVAILABLE", { sha256: null, rows: 10 });
    expect(compareSourceManifestations([a], [b])[0].state).toBe("UNRESOLVED");
  });

  it("classifies identical hash/rows/bytes as the same manifestation", () => {
    expect(compareSourceManifestations([row("s", "AVAILABLE")], [row("s", "AVAILABLE")])[0].state).toBe("SAME_MANIFESTATION");
  });

  it("reopens drift when the immutable hash changes even if row counts match", () => {
    const current = row("s", "AVAILABLE", { sha256: sha("b") });
    expect(compareSourceManifestations([row("s", "AVAILABLE")], [current])[0].state).toBe("DRIFTED");
  });

  it("preserves missing and newly introduced sources as explicit denominator changes", () => {
    const result = compareSourceManifestations([row("old", "AVAILABLE")], [row("new", "AVAILABLE")]);
    expect(result.map((x) => x.state)).toEqual(["NEW_CURRENT", "MISSING_CURRENT"]);
  });
});

describe("MoneySweep stable-ID ranking", () => {
  it("ranks by numeric value with stable ID as deterministic tie breaker", () => {
    const ranked = rankStableRows([{ stableId: "b", label: "B", value: 5 }, { stableId: "a", label: "A", value: 5 }, { stableId: "c", label: "C", value: 9 }]);
    expect(ranked.map((r) => [r.stableId, r.rank])).toEqual([["c", 1], ["a", 2], ["b", 2]]);
  });

  it("excludes nulls rather than coercing them to zero", () => {
    expect(rankStableRows([{ stableId: "a", label: "A", value: null }, { stableId: "b", label: "B", value: 0 }])).toEqual([{ stableId: "b", label: "B", value: 0, rank: 1 }]);
  });

  it("fails closed on duplicate stable IDs", () => {
    expect(() => rankStableRows([{ stableId: "x", label: "A", value: 1 }, { stableId: "x", label: "B", value: 2 }])).toThrowError(/duplicate stable ID/);
  });

  it("handles a deterministic 10,000-row stress denominator without label identity", () => {
    const rows = Array.from({ length: 10000 }, (_, i) => ({ stableId: `id-${String(i).padStart(5, "0")}`, label: i % 2 ? "Same Label" : "Same Label", value: i % 100 }));
    const ranked = rankStableRows(rows, 25);
    expect(ranked).toHaveLength(25);
    expect(new Set(ranked.map((r) => r.stableId)).size).toBe(25);
    expect(ranked.every((r) => r.value === 99)).toBeTrue();
  });

  it("publishes explicit source and ranking evidence rules", () => {
    expect(moneySweepSourceCoverageContract.equalCountsProveIdentity).toBeFalse();
    expect(moneySweepSourceCoverageContract.rankingIdentity).toBe("STABLE_ID_ONLY");
    expect(moneySweepSourceCoverageContract.nullValuePolicy).toBe("EXCLUDE_NOT_ZERO");
  });
});
