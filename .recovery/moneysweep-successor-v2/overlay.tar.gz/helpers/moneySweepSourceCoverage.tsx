export type SourceCoverageState = "AVAILABLE" | "NO_DATA" | "BLOCKED" | "FAILED" | "UNRESOLVED" | "PENDING";
export type DriftState = "SAME_MANIFESTATION" | "DRIFTED" | "MISSING_CURRENT" | "NEW_CURRENT" | "UNRESOLVED";

export type SourceManifestation = {
  sourceId: string;
  state: SourceCoverageState;
  required: boolean;
  sha256: string | null;
  rows: number | null;
  bytes: number | null;
  retrievedAt: string | null;
  evidenceRef: string | null;
};

export type SourceCoverageReceipt = {
  schema: "moneysweep-source-coverage/v1";
  sourceCount: number;
  requiredCount: number;
  availableCount: number;
  noDataCount: number;
  blockedCount: number;
  failedCount: number;
  unresolvedCount: number;
  pendingCount: number;
  terminalRequiredCount: number;
  materialRequiredResidue: number;
  publicDataCoverage: number;
  resolvableCoverage: number;
  complete: boolean;
  reasons: string[];
};

export type DriftRecord = {
  sourceId: string;
  state: DriftState;
  previousSha256: string | null;
  currentSha256: string | null;
  previousRows: number | null;
  currentRows: number | null;
  reasons: string[];
};

const validSha256 = (value: string | null) => Boolean(value && /^[a-f0-9]{64}$/i.test(value));
const terminal = (state: SourceCoverageState) => state === "AVAILABLE" || state === "NO_DATA";
const material = (state: SourceCoverageState) => !terminal(state);

export function validateSourceManifestations(rows: SourceManifestation[]) {
  const reasons: string[] = [];
  const ids = new Set<string>();
  for (const row of rows) {
    if (!row.sourceId.trim()) reasons.push("EMPTY_SOURCE_ID");
    if (ids.has(row.sourceId)) reasons.push(`DUPLICATE_SOURCE_ID:${row.sourceId}`);
    ids.add(row.sourceId);
    if (row.state === "AVAILABLE") {
      if (!validSha256(row.sha256)) reasons.push(`AVAILABLE_WITHOUT_SHA256:${row.sourceId}`);
      if (row.rows === null || row.rows < 0) reasons.push(`AVAILABLE_WITHOUT_ROW_COUNT:${row.sourceId}`);
      if (row.bytes === null || row.bytes < 0) reasons.push(`AVAILABLE_WITHOUT_BYTE_COUNT:${row.sourceId}`);
      if (!row.retrievedAt?.endsWith("Z")) reasons.push(`AVAILABLE_WITHOUT_UTC_RETRIEVAL:${row.sourceId}`);
    }
    if (row.state === "NO_DATA" && !row.evidenceRef) reasons.push(`NO_DATA_WITHOUT_EVIDENCE:${row.sourceId}`);
  }
  return { valid: reasons.length === 0, reasons: [...new Set(reasons)].sort() };
}

export function buildSourceCoverageReceipt(rows: SourceManifestation[]): SourceCoverageReceipt {
  const validation = validateSourceManifestations(rows);
  const required = rows.filter((row) => row.required);
  const count = (state: SourceCoverageState) => rows.filter((row) => row.state === state).length;
  const terminalRequiredCount = required.filter((row) => terminal(row.state)).length;
  const materialRequiredResidue = required.filter((row) => material(row.state)).length;
  const publicDataCoverage = required.length ? terminalRequiredCount / required.length : 1;
  const resolvableRequired = required.filter((row) => row.state !== "BLOCKED");
  const resolvableTerminal = resolvableRequired.filter((row) => terminal(row.state)).length;
  const resolvableCoverage = resolvableRequired.length ? resolvableTerminal / resolvableRequired.length : 1;
  const reasons = [...validation.reasons];
  if (materialRequiredResidue) reasons.push(`MATERIAL_REQUIRED_RESIDUE:${materialRequiredResidue}`);
  return {
    schema: "moneysweep-source-coverage/v1",
    sourceCount: rows.length,
    requiredCount: required.length,
    availableCount: count("AVAILABLE"),
    noDataCount: count("NO_DATA"),
    blockedCount: count("BLOCKED"),
    failedCount: count("FAILED"),
    unresolvedCount: count("UNRESOLVED"),
    pendingCount: count("PENDING"),
    terminalRequiredCount,
    materialRequiredResidue,
    publicDataCoverage,
    resolvableCoverage,
    complete: validation.valid && materialRequiredResidue === 0,
    reasons: [...new Set(reasons)].sort(),
  };
}

export function compareSourceManifestations(previous: SourceManifestation[], current: SourceManifestation[]): DriftRecord[] {
  const prior = new Map(previous.map((row) => [row.sourceId, row] as const));
  const now = new Map(current.map((row) => [row.sourceId, row] as const));
  const ids = [...new Set([...prior.keys(), ...now.keys()])].sort();
  return ids.map((sourceId) => {
    const a = prior.get(sourceId);
    const b = now.get(sourceId);
    if (!a) return { sourceId, state: "NEW_CURRENT" as const, previousSha256: null, currentSha256: b?.sha256 ?? null, previousRows: null, currentRows: b?.rows ?? null, reasons: ["SOURCE_NOT_IN_PREVIOUS_DENOMINATOR"] };
    if (!b) return { sourceId, state: "MISSING_CURRENT" as const, previousSha256: a.sha256, currentSha256: null, previousRows: a.rows, currentRows: null, reasons: ["SOURCE_MISSING_FROM_CURRENT_DENOMINATOR"] };
    if (!validSha256(a.sha256) || !validSha256(b.sha256)) return { sourceId, state: "UNRESOLVED" as const, previousSha256: a.sha256, currentSha256: b.sha256, previousRows: a.rows, currentRows: b.rows, reasons: ["IMMUTABLE_HASH_REQUIRED"] };
    const same = a.sha256 === b.sha256 && a.rows === b.rows && a.bytes === b.bytes;
    return {
      sourceId,
      state: same ? "SAME_MANIFESTATION" as const : "DRIFTED" as const,
      previousSha256: a.sha256,
      currentSha256: b.sha256,
      previousRows: a.rows,
      currentRows: b.rows,
      reasons: same ? [] : ["BYTE_OR_ROW_MANIFESTATION_CHANGED"],
    };
  });
}

export type StableRankingInput = { stableId: string; label: string; value: number | null };
export type StableRankingRow = { stableId: string; label: string; value: number; rank: number };

export function rankStableRows(rows: StableRankingInput[], limit = 25): StableRankingRow[] {
  if (!Number.isInteger(limit) || limit < 1) throw new Error("limit must be a positive integer");
  const seen = new Set<string>();
  const eligible: StableRankingRow[] = [];
  for (const row of rows) {
    if (!row.stableId.trim()) continue;
    if (seen.has(row.stableId)) throw new Error(`duplicate stable ID: ${row.stableId}`);
    seen.add(row.stableId);
    if (row.value === null || !Number.isFinite(row.value)) continue;
    eligible.push({ stableId: row.stableId, label: row.label, value: row.value, rank: 0 });
  }
  eligible.sort((a, b) => b.value - a.value || a.stableId.localeCompare(b.stableId));
  let priorValue: number | null = null;
  let priorRank = 0;
  return eligible.slice(0, limit).map((row, index) => {
    const rank = priorValue !== null && row.value === priorValue ? priorRank : index + 1;
    priorValue = row.value;
    priorRank = rank;
    return { ...row, rank };
  });
}

export const moneySweepSourceCoverageContract = {
  schema: "moneysweep-source-coverage/v1" as const,
  noDataRequiresEvidence: true,
  availableRequiresImmutableHash: true,
  equalCountsProveIdentity: false,
  rankingIdentity: "STABLE_ID_ONLY" as const,
  nullValuePolicy: "EXCLUDE_NOT_ZERO" as const,
};
